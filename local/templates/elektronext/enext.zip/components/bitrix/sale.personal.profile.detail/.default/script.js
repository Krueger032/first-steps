BX.namespace('BX.Sale.PersonalProfileComponent');

(function() {
	BX.Sale.PersonalProfileComponent.PersonalProfileDetail = {
		init: function(params) {
			if(BX.type.isPlainObject(params))
				this.ajaxUrl = params.ajaxUrl;
			
			var propertyFileList = document.getElementsByClassName('sppd-input-container-property-file');
			Array.prototype.forEach.call(propertyFileList, function(propertyFile) {
				var deleteFileElement = propertyFile.getElementsByClassName('sppd-property-input-delete-file')[0];
				var inputFile = propertyFile.getElementsByClassName('sppd-input-file')[0];
				var labelFileInfo = propertyFile.getElementsByClassName('sppd-load-file-info')[0];
				var cancelButton = propertyFile.getElementsByClassName('sppd-load-file-cancel')[0];

				BX.bindDelegate(propertyFile, 'click', { 'class': 'sppd-property-check-file' }, BX.proxy(function(event) {
					if(deleteFileElement.value != '') {
						idList = deleteFileElement.value.split(';');
						if(idList.indexOf(event.target.value) === -1) {
							deleteFileElement.value = deleteFileElement.value + ';' + event.target.value;
						} else {
							idList.splice(idList.indexOf(event.target.value), 1);
							deleteFileElement.value = idList.join(';');
						}
					} else {
						deleteFileElement.value = event.target.value;
					}
				}, this));

				BX.bind(inputFile, 'change', BX.delegate(
					function(event) {
						if(event.target.files.length > 1) {
							labelFileInfo.innerHTML = BX.message('SPPD_FILE_COUNT') + event.target.files.length;
							cancelButton.classList.remove('hidden');
						} else if(event.target.files.length == 1) {
							fileName = event.target.files[0].name;
							if(fileName.length > 40) {
								labelFileInfo.innerHTML = fileName.substr(0,9) + '...' + fileName.substr(-9);
							} else {
								labelFileInfo.innerHTML = event.target.files[0].name;
							}
							cancelButton.classList.remove('hidden');
						} else {
							cancelButton.classList.add('hidden');
							labelFileInfo.innerHTML = BX.message('SPPD_FILE_NOT_SELECTED');
						}
					}, this)
				);
				BX.bind(cancelButton, 'click', BX.delegate(
					function() {
						cancelButton.classList.add('hidden');
						labelFileInfo.innerHTML = BX.message('SPPD_FILE_NOT_SELECTED');
						inputFile.value = '';
						inputFile.files = [];
					}, this)
				);
			});

			var multiLocationList = document.getElementsByClassName('input-add-multiple');
			for(var key in multiLocationList) {
				var hiddenLocation = multiLocationList[key];
				if(!BX.type.isDomNode(hiddenLocation) && BX.type.isNotEmptyString(this.ajaxUrl))
					continue;
				BX.bind(hiddenLocation, 'click', BX.delegate(
					function(event) {
						switch(event.target.getAttribute('data-add-type')) {
							case 'LOCATION':
								this.createLocationInput(event);
								break;
							case 'TEXT':
								this.createTextInput(event);
								break;
						}
					}, this)
				);
			}
		},

		createTextInput: function(event) {
			if(!BX.type.isDomNode(event.target))
				return;

			var newInput = BX.create('input', {
				style: {
					marginTop: 6 + 'px'
				},
				attrs: {
					className: 'form-control',
					type: 'text',
					name: event.target.getAttribute('data-add-name')
				}
			});

			event.target.parentNode.insertBefore(newInput, event.target);
		},

		createLocationInput: function(event) {
			var newKey = parseInt(event.target.getAttribute('data-add-last-key')) + 1;
			BX.ajax({
				method: 'POST',
				dataType: 'html',
				url: this.ajaxUrl,
				data: {
					sessid: BX.bitrix_sessid(),
					params: {
						LOCATION_NAME: event.target.getAttribute('data-add-name'),
						LOCATION_TEMPLATE: event.target.getAttribute('data-add-template'),
						LOCATION_KEY: newKey,
						ACTION: 'getLocationHtml'
					},
					signedParamsString: this.signedParams
				},
				onsuccess: BX.proxy(function(result) {
					var wrapper = BX.create('div', {
						style: {
							marginTop: 6 + 'px'
						}
					});
					wrapper.innerHTML = result;
					event.target.parentNode.insertBefore(wrapper,event.target);
					event.target.setAttribute('data-add-last-key', newKey)
				}, this),
				onfailure: BX.proxy(function() {
					return this;
				}, this)
			}, this);
		}
	}
})();
